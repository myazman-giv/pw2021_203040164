<?php
/*
Mochamad Yazman Yazid
203040164
https://github.com/myazman-giv/pw2021_203040164
pertemuan 4 - 1 Maret 2021
Belajar Mengenai Function
*/
?><?php
  // date
  // untuk menampilkan tanggal dengan format tertentu
  // echo date("l, d-M-Y");

  // time
  // UNIX Timestamp / EPOCH time
  // detik yang sudah berlalu sejak 1 januari 1970
  // echo time();
  // echo date ("l, d-M-Y", time()-60*60*24*1000);

  // mktime
  // membuat sendiri detik yangberlalu sejak 
  // mktime (0,0,0,0,0,0)
  // jam, menit, detik, bulan, tanggal,  tahun
  // echo date("l", mktime(0,0,0,8,20,2002)); 

  // strtotime
  // echo date ("l", strtotime ("20 aug 2002"));
  ?>
