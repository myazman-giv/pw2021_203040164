<?php
/*
Mochamad Yazman Yazid
203040164
https://github.com/myazman-giv/pw2021_203040164
pertemuan 9 - 16 April 2021
php
*/
?><?php
  // koneksi ke databse
  $conn = mysqli_connect("localhost", "root", "", "phpdasar");

  function query($query)
  {
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
      $rows[] = $row;
    }
    return $rows;
  }
  ?>