<?php
/*
Mochamad Yazman Yazid
203040164
https://github.com/myazman-giv/pw2021_203040164
pertemuan 3 - 23 Februari 2021
php
*/
?><?php
  // pengulangan
  // for
  // while
  // do.. while
  // foreach : pengulanagn khusus array

  // for
  // for( $i = 0; $i < 5; $i ++ ) {
  //     echo "Hello Word! ";
  // }

  // while
  // $i = 0;
  // while ($i<5 ) {
  //     echo "Hello Word! <br>";
  // $i++;
  // }

  // do.. while
  // $i = 0;
  // do {
  //     echo "Hello Word! <br>";
  // $i++;
  // } while ($i < 5);

  // pengkondisian
  // if else
  // if else if else
  // ternary
  // switch

  //if else
  // $x = 10;
  // if ( $x < 9){
  //     echo "betul";
  // }else if ($x == 10){
  //     echo "binggo";
  // } 
  // else {
  //     echo "salah";
  // }
  ?>

