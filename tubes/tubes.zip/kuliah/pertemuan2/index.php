<?php 
/*
Mochamad Yazman Yazid
203040164
https://github.com/myazman-giv/pw2021_203040164
pertemuan 2 - 13 Februari 2021
Mempelajari mengenai sintaks PHP 
*/ 
?>  
<?php
// pertemuan 2 - PHP Dasar
// sintaks PHP

// Standar Output
// echo, print
// print_r
// var_dump

// Penulisan sintak PHP
// 1. PHP di dalam html
// 2. html di dalam PHP

// Variabel dan Tipe Data
// Variabel 
// tidak boleh di awali dengan angka, tapi boleh mengandung angka
// $nama = "Mochamad Yazman Yazid"
// echo 'Halo, nama saya $nama';

// Operator
// aritmetika
// + - * / %
// $x = 10;
// $y = 20;
// echo $x * $y;

// Penggabung string / concatenation / concat
// . 
// $nama_depan = "Yazman"
// $nama_belakang = "Yazid"
// echo $nama_depan . " " . $nama_belakang;

// Assigment
// =, +=, -=, *=, /=, %=, .=
// $x = 2;
// $x = 10;
// echo $x;
// $nama = "Yazman";
// $nama = " ";
// $nama = "Yazid";
// echo $nama;

// Perbandingan
// <, >, <=, >=, !=, ==
// var_dump(2 == "2");

// Identitas
// ===, !==
// var_dump(2 === "2")

// Logika
// &&, ||, !
// $x = 9;
// var_dump($x < 19 || $x % 2 === 0 );
?>