<?php
/*
Mochamad Yazman Yazid
203040164
https://github.com/myazman-giv/pw2021_203040164
tugas Besar
php
*/
?><?php
  session_start();
  session_destroy();
  header("Location: ../index.php");
  exit;
  ?>