<?php 
/*
Mochamad Yazman Yazid
203040164
https://github.com/myazman-giv/pw2021_203040164
pertemuan 3 
php
*/ 
?>
<?php

    $string = ["ada", "abel", "men", "pung", "nilai"];

    echo "Array $string[0]lah suatu vari$string[1] yang dapat $string[2]am$string[3] banyak $string[4]";
?>