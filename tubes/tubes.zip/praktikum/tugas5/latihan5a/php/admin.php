<?php 
// menghubungkan dengan file php lainya
require 'functions.php';
// melakukan query
$sapi = query("SELECT * FROM sapi");
?>