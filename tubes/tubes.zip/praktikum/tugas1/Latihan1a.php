<?php 
/*
Mochamad Yazman Yazid
203040164
https://github.com/myazman-giv/pw2021_203040164
*/ 
?>  


<?php

    for( $i = 1; $i <= 3; $i++ ) {
        for( $j = 1; $j <= 3 ; $j++ ) {
            echo "Ini perulangan ke ( $i,$j ) <br>";
        }
    }

?>